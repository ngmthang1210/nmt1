#from django.contrib import admin
#from .models import Post
#admin.site.register(Post)
from django.contrib import admin
from .models import Post

class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'created_at')  # Thêm các trường bạn muốn hiển thị ở danh sách
    search_fields = ('title', 'content')    # Cho phép tìm kiếm trong admin

admin.site.register(Post, PostAdmin)
